package upmc.game;

public class BadMenuChoiceException extends RuntimeException {

}
