package upmc.game;

import java.util.*;

public interface LecturePseudo
{
  public ArrayList<String> lirePseudo();
}
